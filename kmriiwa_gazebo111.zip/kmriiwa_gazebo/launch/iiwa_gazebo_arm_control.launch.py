from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # Dummy arm controller node
    iiwa_gazebo_controller_node = Node(
        package='kmriiwa_gazebo',  # Replace with your package name
        executable='iiwa_gazebo_arm_controllers.py',
        name='iiwa_gazebo_arm_controller',
        output='screen'
    )
    
    return LaunchDescription([
        iiwa_gazebo_controller_node
    ])
