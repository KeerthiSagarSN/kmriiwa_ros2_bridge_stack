#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import math
import time

class DummyArmController(Node):
    def __init__(self):
        super().__init__('iiwa_gazebo_arm_controller')
        self.publisher = self.create_publisher(JointState, '/kmriiwa/arm/joint_states', 10)
        self.timer = self.create_timer(0.02, self.timer_callback)  # 50 Hz
        self.joint_names = [
            'kmriiwa_joint_1',
            'kmriiwa_joint_2',
            'kmriiwa_joint_3',
            'kmriiwa_joint_4',
            'kmriiwa_joint_5',
            'kmriiwa_joint_6',
            'kmriiwa_joint_7'
        ]
        self.start_time = time.time()
        
    def timer_callback(self):
        elapsed = time.time() - self.start_time
        
        # Create simple oscillating pattern for joints
        positions = [
            0.3 * math.sin(elapsed * 0.3),             # Joint 1
            0.2 * math.sin(elapsed * 0.4 + 0.5),       # Joint 2
            0.3 * math.sin(elapsed * 0.2 + 1.0),       # Joint 3
            0.2 * math.sin(elapsed * 0.3 + 1.5),       # Joint 4
            0.3 * math.sin(elapsed * 0.4 + 2.0),       # Joint 5
            0.2 * math.sin(elapsed * 0.5 + 2.5),       # Joint 6
            0.3 * math.sin(elapsed * 0.6 + 3.0)        # Joint 7
        ]
        
        # Create and publish joint state message
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = self.joint_names
        msg.position = positions
        msg.velocity = [0.0] * len(self.joint_names)  # Not setting velocities
        msg.effort = [0.0] * len(self.joint_names)    # Not setting efforts
        
        self.publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    controller = DummyArmController()
    rclpy.spin(controller)
    controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()