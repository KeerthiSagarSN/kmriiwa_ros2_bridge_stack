#include <gazebo/common/Plugin.hh>
#include <rclcpp/rclcpp.hpp>

namespace gazebo
{
class KmriiwaPluginGazebo : public WorldPlugin
{
public:
  KmriiwaPluginGazebo() : WorldPlugin()
  {
  }
  
  void Load(physics::WorldPtr _world, sdf::ElementPtr _sdf)
  {
    // Initialize ROS node
    rclcpp::InitOptions options;
    rclcpp::Context::SharedPtr context = std::make_shared<rclcpp::Context>();
    context->init(0, nullptr, options);
    
    ros_node_ = std::make_shared<rclcpp::Node>("kmriiwa_plugin_node", rclcpp::NodeOptions().context(context));
    
    // Check if the ROS node has been initialized
    if (!rclcpp::ok(context))
    {
      RCLCPP_FATAL(ros_node_->get_logger(), 
        "A ROS2 node could not be initialized, unable to load plugin.");
      return;
    }
    
    RCLCPP_INFO(ros_node_->get_logger(), "Hello World!");
    
    // Keep the node alive
    executor_ = std::make_shared<rclcpp::executors::SingleThreadedExecutor>();
    executor_->add_node(ros_node_);
    
    // Start the executor in a separate thread
    executor_thread_ = std::thread([this]() { this->executor_->spin(); });
  }

  ~KmriiwaPluginGazebo()
  {
    // Stop the executor thread
    if (executor_)
    {
      executor_->cancel();
      if (executor_thread_.joinable())
      {
        executor_thread_.join();
      }
    }
  }

private:
  rclcpp::Node::SharedPtr ros_node_;
  std::shared_ptr<rclcpp::executors::SingleThreadedExecutor> executor_;
  std::thread executor_thread_;
};

GZ_REGISTER_WORLD_PLUGIN(KmriiwaPluginGazebo)
}
