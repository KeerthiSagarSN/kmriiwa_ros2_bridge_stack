from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, Command
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.conditions import IfCondition, UnlessCondition
import os

def generate_launch_description():
    # Declare launch arguments
    declared_arguments = [
        DeclareLaunchArgument('robot_name', default_value='kmriiwa',
                             description='Robot name'),
        DeclareLaunchArgument('controllers', default_value='joint_state_controller manipulator_controller',
                             description='Controllers to spawn'),
        DeclareLaunchArgument('hardware_interface', default_value='EffortJointInterface',
                             description='Hardware interface type'),
        DeclareLaunchArgument('robot_extras',
                             default_value=PathJoinSubstitution([FindPackageShare('kmriiwa_description'), 'urdf', 'robot', 'empty.xacro']),
                             description='Extra robot description files'),
        DeclareLaunchArgument('joint_state_frequency', default_value='50',
                             description='Joint state publisher frequency'),
        DeclareLaunchArgument('use_sim_time', default_value='true',
                             description='Use simulation time'),
        DeclareLaunchArgument('load_arm_controllers', default_value='true',
                             description='Whether to load arm controllers'),
    ]
    
    # Access launch arguments
    robot_name = LaunchConfiguration('robot_name')
    controllers_str = LaunchConfiguration('controllers')
    hardware_interface = LaunchConfiguration('hardware_interface')
    robot_extras = LaunchConfiguration('robot_extras')
    joint_state_frequency = LaunchConfiguration('joint_state_frequency')
    use_sim_time = LaunchConfiguration('use_sim_time')
    load_arm_controllers = LaunchConfiguration('load_arm_controllers')
    
    # Package paths
    kmriiwa_gazebo_pkg = FindPackageShare('kmriiwa_gazebo')
    kmriiwa_description_pkg = FindPackageShare('kmriiwa_description')
    
    # Controller configuration
    controller_config_file = PathJoinSubstitution(
        [kmriiwa_gazebo_pkg, 'config', 'gazebo_iiwa_control.yaml']
    )
    
    # Fallback joint state publisher (used when controllers are not loaded)
    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
        parameters=[{
            'use_sim_time': use_sim_time,
            'rate': joint_state_frequency
        }],
        output='screen',
        condition=UnlessCondition(load_arm_controllers)
    )
    
    # Controller spawner (when controllers are enabled)
    arm_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=[
            'joint_state_controller',
            'manipulator_controller'
        ],
        parameters=[{'use_sim_time': use_sim_time}],
        namespace='/kmriiwa/arm',
        output='screen',
        condition=IfCondition(load_arm_controllers)
    )
    
    # Create and return the launch description
    return LaunchDescription(declared_arguments + [
        joint_state_publisher_node,
        arm_controller_spawner
    ])