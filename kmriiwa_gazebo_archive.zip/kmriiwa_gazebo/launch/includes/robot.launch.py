from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, ExecuteProcess
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, Command, TextSubstitution
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
import os


def generate_launch_description():
    # Declare launch arguments
    declared_arguments = [
        DeclareLaunchArgument('robot_name', default_value='kmriiwa',
                              description='Robot name'),
        DeclareLaunchArgument('hardware_interface', default_value='PositionJointInterface',
                              description='Hardware interface type'),
        DeclareLaunchArgument('robot_extras', 
                              default_value=PathJoinSubstitution([FindPackageShare('kmriiwa_description'), 'urdf', 'robot', 'empty.xacro']),
                              description='Extra robot description files'),
        DeclareLaunchArgument('robot_state_frequency', default_value='20',
                              description='Robot state publisher frequency'),
        DeclareLaunchArgument('init_pose_x', default_value='0.0',
                              description='Initial x position'),
        DeclareLaunchArgument('init_pose_y', default_value='0.0',
                              description='Initial y position'),
        DeclareLaunchArgument('init_pose_z', default_value='0.0',
                              description='Initial z position'),
        DeclareLaunchArgument('init_pose_yaw', default_value='0.0',
                              description='Initial yaw rotation'),
        DeclareLaunchArgument('use_sim_time', default_value='true',
                              description='Use simulation time'),
        DeclareLaunchArgument('load_arm_controllers', default_value='false',
                              description='Whether to load arm controllers'),
    ]

    # Access launch arguments
    robot_name = LaunchConfiguration('robot_name')
    hardware_interface = LaunchConfiguration('hardware_interface')
    robot_extras = LaunchConfiguration('robot_extras')
    robot_state_frequency = LaunchConfiguration('robot_state_frequency')
    init_pose_x = LaunchConfiguration('init_pose_x')
    init_pose_y = LaunchConfiguration('init_pose_y')
    init_pose_z = LaunchConfiguration('init_pose_z')
    init_pose_yaw = LaunchConfiguration('init_pose_yaw')
    use_sim_time = LaunchConfiguration('use_sim_time')

    # Include the robot description launch file
    kmriiwa_description_pkg = FindPackageShare('kmriiwa_description')
    
    # Get the robot description from xacro
    robot_description_content = Command([
        'xacro',
        ' ',
        PathJoinSubstitution([kmriiwa_description_pkg, 'urdf', 'robot', 'kmriiwa.urdf.xacro']),
        ' hardware_interface:=',
        hardware_interface,
        ' robot_extras:=',
        robot_extras
    ])

    # Pre-generate a URDF file - this uses a fixed path, not substitutions
    pkg_path = FindPackageShare('kmriiwa_description').find('kmriiwa_description')
    xacro_path = os.path.join(pkg_path, 'urdf', 'robot', 'kmriiwa.urdf.xacro')
    
    # We're using a fixed command here to bypass substitution issues
    generate_urdf_file = ExecuteProcess(
        cmd=['bash', '-c', f'xacro {xacro_path} > /tmp/kmriiwa.urdf'],
        output='screen'
    )

    # Spawn the robot in Gazebo using the generated URDF file
    spawn_entity_node = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        name='spawn_entity',
        arguments=[
            '-entity', robot_name,
            '-file', '/tmp/kmriiwa.urdf',  # Use the pre-generated file
            '-x', init_pose_x,
            '-y', init_pose_y,
            '-z', init_pose_z,
            '-Y', init_pose_yaw
        ],
        output='screen'
    )

    # Robot state publisher with fixed parameter types
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[
            {
                'robot_description': robot_description_content,
                'publish_frequency': 20,  # Fixed value to avoid type conversion issues
                'use_sim_time': use_sim_time
            }
        ],
        remappings=[
            ('joint_states', '/kmriiwa/arm/joint_states')
        ]
    )

    # Joint state publisher for testing
    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
        parameters=[
            {
                'use_sim_time': use_sim_time,
                'rate': 30
            }
        ],
        output='screen'
    )

    # Joint state publisher GUI for interactive testing
    joint_state_publisher_gui_node = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        parameters=[{'use_sim_time': use_sim_time}],
        output='screen'
    )

    # Container for composable nodes
    composable_node_container = Node(
        package='rclcpp_components',
        executable='component_container',
        name='container',
        output='screen'
    )

    # Return the LaunchDescription
    return LaunchDescription(
        declared_arguments + [
            generate_urdf_file,  # Generate URDF file first
            spawn_entity_node,   # Then spawn the robot
            robot_state_publisher_node,
            joint_state_publisher_node,
            joint_state_publisher_gui_node,
            composable_node_container
        ]
    )
