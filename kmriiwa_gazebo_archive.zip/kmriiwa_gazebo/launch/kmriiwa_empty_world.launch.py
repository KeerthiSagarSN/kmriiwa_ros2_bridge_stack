from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, GroupAction, ExecuteProcess
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, Command, FindExecutable
from launch_ros.actions import Node, PushRosNamespace
from launch_ros.substitutions import FindPackageShare
import os


def generate_launch_description():
    # Declare launch arguments
    declared_arguments = [
        DeclareLaunchArgument('robot_name', default_value='kmriiwa',
                             description='Robot name'),
        DeclareLaunchArgument('hardware_interface', default_value='EffortJointInterface',
                             description='Hardware interface type'),
        DeclareLaunchArgument('controllers', default_value='joint_state_controller manipulator_controller gravity_compensation_controller',
                             description='Controllers to spawn'),
        DeclareLaunchArgument('use_sim_time', default_value='true',
                             description='Use simulation time'),
        DeclareLaunchArgument('debug', default_value='false',
                             description='Start gzserver in debug mode'),
        DeclareLaunchArgument('verbose', default_value='false',
                             description='Verbose output'),
        DeclareLaunchArgument('paused', default_value='false',
                             description='Start in paused state'),
        DeclareLaunchArgument('headless', default_value='false',
                             description='Run headless (without gzclient)'),
        DeclareLaunchArgument('load_arm_controllers', default_value='true',
                             description='Whether to load arm controllers'),
        DeclareLaunchArgument('world', default_value='empty.world',
                             description='World file name (empty.world by default)'),
    ]

    # Get substitution variables
    robot_name = LaunchConfiguration('robot_name')
    hardware_interface = LaunchConfiguration('hardware_interface')
    controllers = LaunchConfiguration('controllers')
    use_sim_time = LaunchConfiguration('use_sim_time')
    debug = LaunchConfiguration('debug')
    verbose = LaunchConfiguration('verbose')
    paused = LaunchConfiguration('paused')
    headless = LaunchConfiguration('headless')
    load_arm_controllers = LaunchConfiguration('load_arm_controllers')
    world_file = LaunchConfiguration('world')

    # Package paths
    kmriiwa_gazebo_pkg = FindPackageShare('kmriiwa_gazebo')
    gazebo_ros_pkg = FindPackageShare('gazebo_ros')

    # World file path
    world_path = PathJoinSubstitution([kmriiwa_gazebo_pkg, 'worlds', world_file])

    # Launch Gazebo
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([gazebo_ros_pkg, 'launch', 'gazebo.launch.py'])
        ]),
        launch_arguments={
            'world': world_path,
            'verbose': verbose,
            'pause': paused,
            'use_sim_time': use_sim_time,
            'debug': debug,
            'headless': headless,
            'gui': 'true'
        }.items()
    )

    # Create robot namespace group
    robot_group = GroupAction([
        PushRosNamespace(robot_name),
        
        # Include robot spawn launch file
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([kmriiwa_gazebo_pkg, 'launch', 'includes', 'robot.launch.py'])
            ]),
            launch_arguments={
                'robot_name': robot_name,
                'hardware_interface': hardware_interface,
                'use_sim_time': use_sim_time,
                'load_arm_controllers': load_arm_controllers,
                'init_pose_x': '0.5',
                'init_pose_y': '0.1', 
                'init_pose_z': '0.5',
                'init_pose_yaw': '0.0'
            }.items()
        ),
        
        # Arm control namespace group
        GroupAction([
            PushRosNamespace('arm'),
            
            # Include gazebo control launch file
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource([
                    PathJoinSubstitution([kmriiwa_gazebo_pkg, 'launch', 'includes', 'kmriiwa_gazebo_control.launch.py'])
                ]),
                launch_arguments={
                    'robot_name': robot_name,
                    'controllers': controllers,
                    'hardware_interface': hardware_interface,
                    'use_sim_time': use_sim_time,
                    'load_arm_controllers': load_arm_controllers
                }.items()
            )
        ])
    ])

    # Launch a node to send initial position commands to keep the arm stable
    initial_pose_commander = Node(
        package='ros2_control_test_nodes',
        executable='publisher_joint_trajectory_position',
        name='initial_pose_commander',
        namespace='$(var robot_name)/arm',
        parameters=[{
            'controller_name': 'manipulator_controller',
            'wait_sec_between_publish': 5,
            'goal_names': ['pos1'],
            'pos1': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            'use_sim_time': use_sim_time
        }],
        condition=IfCondition(load_arm_controllers),
        output='screen'
    )

    # Return the LaunchDescription
    return LaunchDescription(declared_arguments + [
        gazebo_launch,
        robot_group,
        initial_pose_commander
    ])
