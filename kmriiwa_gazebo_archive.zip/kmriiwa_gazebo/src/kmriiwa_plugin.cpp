#include <gazebo/common/Plugin.hh>
#include <rclcpp/rclcpp.hpp>

namespace gazebo
{
class KmriiwaPluginGazebo : public WorldPlugin
{
public:
  KmriiwaPluginGazebo() : WorldPlugin()
  {
  }

  void Load(physics::WorldPtr _world, sdf::ElementPtr _sdf)
  {
    // Make sure the ROS2 node has been initialized
    if (!rclcpp::ok())
    {
      RCLCPP_FATAL(rclcpp::get_logger("kmriiwa_plugin"), 
                  "A ROS2 node has not been initialized, unable to load plugin.");
      return;
    }

    // Initialize ROS2 node
    node_ = std::make_shared<rclcpp::Node>("kmriiwa_plugin_node");
    
    RCLCPP_INFO(node_->get_logger(), "Hello World!");
  }

private:
  // Pointer to the ROS2 node
  rclcpp::Node::SharedPtr node_;
};

GZ_REGISTER_WORLD_PLUGIN(KmriiwaPluginGazebo)
}  // namespace gazebo