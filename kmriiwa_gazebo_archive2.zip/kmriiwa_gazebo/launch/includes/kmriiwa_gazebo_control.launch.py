from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, RegisterEventHandler
from launch.event_handlers import OnProcessStart
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, Command
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    # Declare arguments
    declared_arguments = [
        DeclareLaunchArgument('robot_name', default_value='kmriiwa',
                             description='Robot name'),
        DeclareLaunchArgument('controllers', default_value='joint_state_broadcaster manipulator_controller',
                             description='Controllers to spawn'),
        DeclareLaunchArgument('hardware_interface', default_value='PositionJointInterface',
                             description='Hardware interface type'),
        DeclareLaunchArgument('robot_extras', default_value='$(find kmriiwa_description)/urdf/robot/empty.xacro',
                             description='Robot extras xacro'),
        DeclareLaunchArgument('joint_state_frequency', default_value='20',
                             description='Joint state frequency'),
        DeclareLaunchArgument('use_sim_time', default_value='true',
                             description='Use simulation time')
    ]

    # Get substitution for arguments
    robot_name = LaunchConfiguration('robot_name')
    controllers = LaunchConfiguration('controllers')
    hardware_interface = LaunchConfiguration('hardware_interface')
    robot_extras = LaunchConfiguration('robot_extras')
    joint_state_frequency = LaunchConfiguration('joint_state_frequency')
    use_sim_time = LaunchConfiguration('use_sim_time')

    # Get package dirs
    kmriiwa_gazebo_package = FindPackageShare('kmriiwa_gazebo')
    kmriiwa_description_package = FindPackageShare('kmriiwa_description')

    # Load controller configurations
    controller_config = PathJoinSubstitution([
        kmriiwa_gazebo_package,
        'config',
        'controller_manager.yaml'
    ])

    # Include robot description
    robot_description_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                kmriiwa_description_package,
                'launch',
                'kmriiwa_upload.launch.py'
            ])
        ]),
        launch_arguments={
            'robot_name': robot_name,
            'hardware_interface': hardware_interface,
            'robot_extras': robot_extras
        }.items()
    )

    # Load controllers
    controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=[
            '--controller-manager', '/controller_manager',
            '--controller-manager-timeout', '50.0',
            'joint_state_broadcaster',
            'manipulator_controller'
        ],
        parameters=[
            {'use_sim_time': use_sim_time}
        ],
        output='screen'
    )

    # Return launch description
    return LaunchDescription(declared_arguments + [
        robot_description_launch,
        controller_spawner
    ])
