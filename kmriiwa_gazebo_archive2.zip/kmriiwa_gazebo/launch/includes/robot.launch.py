from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction, GroupAction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node, PushRosNamespace
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import Command


def launch_setup(context, *args, **kwargs):
    # Get parameters
    robot_name = LaunchConfiguration('robot_name').perform(context)
    hardware_interface = LaunchConfiguration('hardware_interface').perform(context)
    robot_extras = LaunchConfiguration('robot_extras').perform(context)
    robot_state_frequency = LaunchConfiguration('robot_state_frequency').perform(context)
    init_pose_x = LaunchConfiguration('init_pose_x').perform(context)
    init_pose_y = LaunchConfiguration('init_pose_y').perform(context)
    init_pose_z = LaunchConfiguration('init_pose_z').perform(context)
    init_pose_yaw = LaunchConfiguration('init_pose_yaw').perform(context)
    use_sim_time = LaunchConfiguration('use_sim_time').perform(context)
    cmd_vel_topic = LaunchConfiguration('cmd_vel_topic').perform(context)
    
    # Get package paths
    kmriiwa_description_pkg = FindPackageShare('kmriiwa_description').find('kmriiwa_description')
    
    # Generate URDF via xacro
    xacro_file = PathJoinSubstitution([
        FindPackageShare('kmriiwa_description'),
        'urdf',
        'kmriiwa.urdf.xacro'
    ]).perform(context)
    
    robot_description_content = Command([
        'xacro', ' ', xacro_file, ' ',
        'robot_name:=', robot_name, ' ',
        'hardware_interface:=', hardware_interface, ' ',
        'robot_extras:=', robot_extras
    ]).perform(context)
    
    robot_description = {'robot_description': robot_description_content}
    
    # Spawn robot
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        name='spawn_entity',
        namespace=robot_name,
        arguments=[
            '-entity', robot_name,
            '-x', init_pose_x,
            '-y', init_pose_y,
            '-z', init_pose_z,
            '-Y', init_pose_yaw,
            '-topic', f'/{robot_name}/robot_description'
        ],
        output='screen'
    )
    
    # Robot state publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        namespace=robot_name,
        output='screen',
        parameters=[
            robot_description,
            {'use_sim_time': use_sim_time},
            {'publish_frequency': float(robot_state_frequency)}
        ],
        remappings=[
            ('joint_states', 'arm/joint_states')
        ]
    )
    
    # Return nodes to launch
    return [
        spawn_entity,
        robot_state_publisher
    ]


def generate_launch_description():
    declared_arguments = [
        DeclareLaunchArgument('robot_name', default_value='kmriiwa',
                             description='Robot name'),
        DeclareLaunchArgument('hardware_interface', default_value='PositionJointInterface',
                             description='Hardware interface type'),
        DeclareLaunchArgument('robot_extras', default_value='$(find kmriiwa_description)/urdf/robot/empty.xacro',
                             description='Robot extras xacro'),
        DeclareLaunchArgument('robot_state_frequency', default_value='20',
                             description='Robot state publisher frequency'),
        DeclareLaunchArgument('init_pose_x', default_value='0.0',
                             description='Initial x position'),
        DeclareLaunchArgument('init_pose_y', default_value='0.0',
                             description='Initial y position'),
        DeclareLaunchArgument('init_pose_z', default_value='0.0',
                             description='Initial z position'),
        DeclareLaunchArgument('init_pose_yaw', default_value='0.0',
                             description='Initial yaw rotation'),
        DeclareLaunchArgument('use_sim_time', default_value='true',
                             description='Use simulation time'),
        DeclareLaunchArgument('cmd_vel_topic', default_value='/kmriiwa/cmd_vel',
                             description='Topic for velocity commands')
    ]
    
    return LaunchDescription(
        declared_arguments + [OpaqueFunction(function=launch_setup)]
    )
