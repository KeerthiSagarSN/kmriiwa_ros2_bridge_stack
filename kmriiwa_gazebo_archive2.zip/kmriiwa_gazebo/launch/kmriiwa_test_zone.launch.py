from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, SetEnvironmentVariable, GroupAction, IncludeLaunchDescription
from launch.conditions import UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, EnvironmentVariable
from launch_ros.actions import Node, PushRosNamespace
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    # Declare all launch arguments
    declared_arguments = [
        DeclareLaunchArgument('robot_name', default_value='kmriiwa',
                             description='Robot name'),
        DeclareLaunchArgument('hardware_interface', default_value='PositionJointInterface',
                             description='Hardware interface type'),
        DeclareLaunchArgument('controllers', default_value='joint_state_broadcaster manipulator_controller',
                             description='Controllers to spawn'),
        DeclareLaunchArgument('init_pose_x', default_value='1.5',
                             description='Initial x position'),
        DeclareLaunchArgument('init_pose_y', default_value='0.0',
                             description='Initial y position'),
        DeclareLaunchArgument('init_pose_z', default_value='0.0',
                             description='Initial z position'),
        DeclareLaunchArgument('init_pose_yaw', default_value='0.0',
                             description='Initial yaw rotation'),
        DeclareLaunchArgument('use_sim_time', default_value='true',
                             description='Use simulation time'),
        DeclareLaunchArgument('debug', default_value='false',
                             description='Start gzserver in debug mode'),
        DeclareLaunchArgument('verbose', default_value='false',
                             description='Start with verbose output'),
        DeclareLaunchArgument('paused', default_value='true',
                             description='Start in paused state'),
        DeclareLaunchArgument('headless', default_value='false',
                             description='Run headless (without gzclient)'),
        DeclareLaunchArgument('cmd_vel_topic', default_value='/kmriiwa/cmd_vel',
                             description='Topic for velocity commands')
    ]

    # Get substitution variables
    robot_name = LaunchConfiguration('robot_name')
    hardware_interface = LaunchConfiguration('hardware_interface')
    controllers = LaunchConfiguration('controllers')
    init_pose_x = LaunchConfiguration('init_pose_x')
    init_pose_y = LaunchConfiguration('init_pose_y')
    init_pose_z = LaunchConfiguration('init_pose_z')
    init_pose_yaw = LaunchConfiguration('init_pose_yaw')
    use_sim_time = LaunchConfiguration('use_sim_time')
    debug = LaunchConfiguration('debug')
    verbose = LaunchConfiguration('verbose')
    paused = LaunchConfiguration('paused')
    headless = LaunchConfiguration('headless')
    cmd_vel_topic = LaunchConfiguration('cmd_vel_topic')

    # Package paths
    kmriiwa_gazebo_pkg = FindPackageShare('kmriiwa_gazebo')
    gazebo_ros_pkg = FindPackageShare('gazebo_ros')

    # Set model path
    gazebo_model_path = SetEnvironmentVariable(
        name='GAZEBO_MODEL_PATH',
        value=[
            EnvironmentVariable('GAZEBO_MODEL_PATH', default_value=''),
            ':',
            PathJoinSubstitution([kmriiwa_gazebo_pkg, 'worlds', 'models'])
        ]
    )

    # World file path
    world_path = PathJoinSubstitution([kmriiwa_gazebo_pkg, 'worlds', 'test_zone.world'])

    # Launch Gazebo server
    gazebo_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([gazebo_ros_pkg, 'launch', 'gzserver.launch.py'])
        ]),
        launch_arguments={
            'world': world_path,
            'verbose': verbose,
            'pause': paused,
            'use_sim_time': use_sim_time,
            'debug': debug,
        }.items()
    )

    # Launch Gazebo client
    gazebo_client = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([gazebo_ros_pkg, 'launch', 'gzclient.launch.py'])
        ]),
        condition=UnlessCondition(headless)
    )

    # Create robot namespace group
    robot_group = GroupAction([
        PushRosNamespace(robot_name),
        
        # Include robot spawn launch file
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([kmriiwa_gazebo_pkg, 'launch', 'robot.launch.py'])
            ]),
            launch_arguments={
                'robot_name': robot_name,
                'hardware_interface': hardware_interface,
                'init_pose_x': init_pose_x,
                'init_pose_y': init_pose_y,
                'init_pose_z': init_pose_z,
                'init_pose_yaw': init_pose_yaw,
                'cmd_vel_topic': cmd_vel_topic,
                'use_sim_time': use_sim_time
            }.items()
        ),
        
        # Arm control namespace group
        GroupAction([
            PushRosNamespace('arm'),
            
            # Include gazebo control launch file
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource([
                    PathJoinSubstitution([kmriiwa_gazebo_pkg, 'launch', 'kmriiwa_gazebo_control.launch.py'])
                ]),
                launch_arguments={
                    'robot_name': robot_name,
                    'controllers': controllers,
                    'hardware_interface': hardware_interface,
                    'use_sim_time': use_sim_time
                }.items()
            )
        ])
    ])

    # Optional: Add a cmd_vel bridge to handle command velocity
    cmd_vel_bridge = Node(
        package='topic_tools',
        executable='relay',
        name='cmd_vel_relay',
        parameters=[
            {'use_sim_time': use_sim_time}
        ],
        remappings=[
            ('input', cmd_vel_topic),
            ('output', [robot_name, '/base/command/cmd_vel'])
        ]
    )

    # Return the LaunchDescription
    return LaunchDescription(declared_arguments + [
        gazebo_model_path,
        gazebo_server,
        gazebo_client,
        robot_group,
        cmd_vel_bridge
    ])
