#include <gazebo/common/Plugin.hh>
#include <gazebo/physics/World.hh>
#include <gazebo/physics/Model.hh>
#include <rclcpp/rclcpp.hpp>

namespace gazebo
{
class KmriiwaPluginGazebo : public WorldPlugin
{
public:
  KmriiwaPluginGazebo() : WorldPlugin()
  {
  }

  void Load(physics::WorldPtr _world, sdf::ElementPtr _sdf)
  {
    // Initialize ROS node
    if (!rclcpp::ok())
    {
      RCLCPP_FATAL(rclcpp::get_logger("kmriiwa_plugin_node"), 
                   "A ROS node for Gazebo has not been initialized. "
                   "Unable to load plugin. "
                   "Make sure gazebo_ros_init has been loaded.");
      return;
    }

    // Create ROS node if it doesn't exist yet
    if (!node_)
    {
      node_ = rclcpp::Node::make_shared("kmriiwa_plugin_node");
    }
    
    RCLCPP_INFO(node_->get_logger(), "Hello World!");
    
    // Keep a pointer to the world
    world_ = _world;
    
    // Create a timer to spin the node
    update_timer_ = node_->create_wall_timer(
      std::chrono::milliseconds(100),
      std::bind(&KmriiwaPluginGazebo::OnUpdate, this));
  }

private:
  // Called periodically to keep the node alive
  void OnUpdate()
  {
    rclcpp::spin_some(node_);
  }

  // Pointer to the ROS node
  rclcpp::Node::SharedPtr node_;
  
  // Pointer to the world
  physics::WorldPtr world_;
  
  // Timer for updates
  rclcpp::TimerBase::SharedPtr update_timer_;
};

GZ_REGISTER_WORLD_PLUGIN(KmriiwaPluginGazebo)
}
