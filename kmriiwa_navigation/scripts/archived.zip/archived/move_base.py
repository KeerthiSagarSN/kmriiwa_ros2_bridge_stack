#!/usr/bin/env python3

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal


def movebase_client():
    client = actionlib.SimpleActionClient('/kmriiwa/move_base',MoveBaseAction)
    client.wait_for_server()
    goal = MoveBaseGoal()
    goal.target_pose.header.frame_id = "map"
    goal.target_pose.header.stamp = rospy.Time.now()
    goal.target_pose.pose.position.x = 0 #(0,0 Infront of Keerthi cell -> Map = bay3_v02 )
    goal.target_pose.pose.position.y = 0
    goal.target_pose.pose.orientation.x = 0
    goal.target_pose.pose.orientation.y = 0
    goal.target_pose.pose.orientation.z = 0
    goal.target_pose.pose.orientation.w = 1

    client.send_goal(goal)
    wait = client.wait_for_result()
    if not wait:
        rospy.logerr("Action server not available!")
        rospy.signal_shutdown("Action server not available!")
    else:
        return client.get_result()   

if __name__ == '__main__':
    try:
        rospy.init_node('movebase_client_py')
        result = movebase_client()
        if result:
            rospy.loginfo("Goal execution done!")
    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation test finished.")



#Aswin Cell Position (-4.75, 1.35)
#PennE Cell Position (0,1.35)
#Kerth Cell Position (0,0)
#AAyus Cell Position (-4.75,0.2)
# To rotate about turn (x,y,z,w) - > (0,0,0.9999997,0.0007963)
#Center infron of bin picking Cell Position (-8.75,0.5)
#Towards KR70 Cell Position (-13.75,0.375)
#Rotate again (x,y,z,w) - > (0,0,0,1)

