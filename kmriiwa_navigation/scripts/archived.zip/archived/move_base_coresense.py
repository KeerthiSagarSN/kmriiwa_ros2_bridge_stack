#!/usr/bin/env python3
import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Pose

class kmr_iiwa_base_move():
    def __init__(self):
        self.client = actionlib.SimpleActionClient('/kmriiwa/move_base',MoveBaseAction)


    def movebase_client(self,x):
        self.client.wait_for_server()
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()
        goal.target_pose.pose.position.x = float(x[0]) #(0,0 Infront of Keerthi cell -> Map = bay3_v02 )
        goal.target_pose.pose.position.y = float(x[1])
        goal.target_pose.pose.orientation.x = float(x[2])
        goal.target_pose.pose.orientation.y = float(x[3])
        goal.target_pose.pose.orientation.z = float(x[4])
        goal.target_pose.pose.orientation.w = float(x[5])

        self.client.send_goal(goal)
        wait = self.client.wait_for_result()
        if not wait:
            rospy.logerr("Action server not available!")
            rospy.signal_shutdown("Action server not available!")
        else:
            return self.client.get_result() 
          

if __name__ == '__main__':
    
    position_lists = []
    
    try:
        rospy.init_node('movebase_client_py')
        kmr_iiwa_move = kmr_iiwa_base_move()
        
        # old demo points
        #position_lists.append([2.638,-1.298,0,0,0,1]) # 3D Printing cell

        # new demo points
        #position_lists.append([3.2526871465992465,0.014774616024422843,0,0,0,1]) # Mid point for 3D Printing cell
        position_lists.append([6.474208360020238,-0.24058081857955735,0,0,0,1]) # Mid point for 3D Printing cell
        #position_lists.append([8.890382842810087,-1.8686570252329744,0,0,0,1]) #3D Printing Cell
        
        
        for number_of_positions in range(0,len(position_lists)):
            positions = (position_lists[number_of_positions])
            results = kmr_iiwa_move.movebase_client(positions)
            if results:
                rospy.loginfo("Goal execution done!")


    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation test finished.")

        # /kmriiwa/base/state/RobotStatus







  #position_lists.append([2.638,-1.298,0,0,0,1]) # 3D Printing cell
        #position_lists.append([5.333,0.9114,0,0,0,1]) # Mid point for Inpsection Cell
        #position_lists.append([8.407,1.380,0,0,0,1]) #  Inspection Cell
        #position_lists.append([7.552,1.537,0,0,0,1]) #  Moving towards Assembly Cell
        #position_lists.append([4.610,1.277,0,0,0,1]) #  Assembly Cell
        #position_lists.append([0.578,-0.3393,0,0,0,1]) #  Back to initial point
        #position_lists.append([5.268,0.6075,0,0,1,0]) # Mid point for inspection cell
        #position_lists.append([2.971,-1.599,0,0,0,1]) # 3D Printing cell

  #position_lists.append([4.4565,0.75487,0,0,0,1]) # Mid point for inspection cell    
        #position_lists.append([8.517,1.53,0,0,0,1]) #  Inspection Cell
        #position_lists.append([8.517,1.53,0,0,1,0]) #  Inspection Cell
        #position_lists.append([4.610,1.277,0,0,0,1]) #Assembly Cell
        #position_lists.append([0.1678,-0.01493,0,0,0,1])


        # Program the cube pick and place


        ### make all ARM commands above here
        #position_lists.append([0,0,0,0,0.9999997,0.0007963]) # Arm and base reorient
        #position_lists.append([-4.75,0.5,0,0,1,0.0]) # Aayush cell
        #position_lists.append([-8.75,0.5,0,0,1,0.00])  # Near Bay 3- blue lines
        #position_lists.append([-4.75, 1.35,0,0,0,1]) # Aswin Cell
        # print(position_lists)