#!/usr/bin/env python3
import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Pose

class kmr_iiwa_base_move():
    def __init__(self):
        self.client = actionlib.SimpleActionClient('/kmriiwa/move_base',MoveBaseAction)


    def movebase_client(self,x):
        self.client.wait_for_server()
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()
        goal.target_pose.pose.position.x = float(x[0]) #(0,0 Infront of Keerthi cell -> Map = bay3_v02 )
        goal.target_pose.pose.position.y = float(x[1])
        goal.target_pose.pose.orientation.x = float(x[2])
        goal.target_pose.pose.orientation.y = float(x[3])
        goal.target_pose.pose.orientation.z = float(x[4])
        goal.target_pose.pose.orientation.w = float(x[5])

        self.client.send_goal(goal)
        wait = self.client.wait_for_result()
        if not wait:
            rospy.logerr("Action server not available!")
            rospy.signal_shutdown("Action server not available!")
        else:
            return self.client.get_result() 
          

if __name__ == '__main__':
    
    position_lists = []
    
    try:
        rospy.init_node('movebase_client_py')
        kmr_iiwa_move = kmr_iiwa_base_move()
        
     
        #position_lists.append([14.584765190209325,0.8524928794968102,0,0,1,0]) # Mid point for Inspection Cell
        #position_lists.append([11.258698574848232,0.9787469488450701,0,0,1,0]) # Assembly Cell
        position_lists.append([6.349122550110111,-0.09777918396093493,0,0,1,0]) # Back to initial point
        position_lists.append([0.15133437349932619,-0.060470608381884554,0,0,1,0]) # Back to Initial point
        position_lists.append([0.025138049939463752,-0.0064529444114376205,0,0,0,1]) # Assembly Cell
        
        for number_of_positions in range(0,len(position_lists)):
            positions = (position_lists[number_of_positions])
            results = kmr_iiwa_move.movebase_client(positions)
            if results:
                rospy.loginfo("Goal execution done!")


    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation test finished.")

        # /kmriiwa/base/state/RobotStatus




  #position_lists.append([4.610,1.277,0,0,1,0]) #Assembly Cell
        #position_lists.append([0.1678,-0.01493,0,0,0,1])

        # Program the cube pick and place


        ### make all ARM commands above here
        #position_lists.append([0,0,0,0,0.9999997,0.0007963]) # Arm and base reorient
        #position_lists.append([-4.75,0.5,0,0,1,0.0]) # Aayush cell
        #position_lists.append([-8.75,0.5,0,0,1,0.00])  # Near Bay 3- blue lines
        #position_lists.append([-4.75, 1.35,0,0,0,1]) # Aswin Cell
        # print(position_lists)