#!/usr/bin/env python3
import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Pose, PoseStamped
from sensor_msgs.msg import JointState
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from kmriiwa_msgs.msg import JointPosition
from std_msgs.msg import String
import numpy
from threading import Lock
from std_msgs.msg import Float32, Float32MultiArray
from numpy import deg2rad,zeros


# Import PyKDL - Kinematics and Dynamics Laboratory
import PyKDL 


## Initializing IK here ############

import tf_conversions as tf_c
from tf2_ros import TransformBroadcaster


import PyKDL

from urdf_parser_py.urdf import URDF

# from kdl_parser_py import KDL
from kdl_parser_py import urdf


from pykdl_utils.kdl_kinematics import KDLKinematics

#from iiwa_velocity_controller.srv import ControlGripper
#from iiwa_velocity_controller.srv import ReconfigureGripper
from std_srvs.srv import Trigger, TriggerRequest



## I am not using param server robot description -> Be cautious as your urdf and the robot controller may be different


## I built the URDF from XACRO using the terminal command 
#/home/kuka/catkin_iiwa_ws/src/kmriiwa_description/urdf/iiwa14
# THis is bad I am hardcoding, test with the above parameter server and check if it ever works
robot_description = URDF.from_xml_file(
    '/home/research/catkin_ws_kmr/src/kmriiwa_ros_stack/kmriiwa_description/urdf/robot/kmriiwa.urdf')

# Build the tree here from the URDF parser file from the file location

build_ok, kdl_tree = urdf.treeFromFile('/home/research/catkin_ws_kmr/src/kmriiwa_ros_stack/kmriiwa_description/urdf/robot/kmriiwa.urdf')

if build_ok == True:
    print('KDL chain built successfully using URDF!!')
else:
    print('KDL chain unsuccessful using URDF')


# Build the kdl_chain here
kdl_chain = kdl_tree.getChain("kmriiwa_base_footprint", "kmriiwa_link_ee")

joint_states_positions = JointState()
joint_states_positions.name =  ['kmriiwa_joint_1', 'kmriiwa_joint_2','kmriiwa_joint_3', 'kmriiwa_joint_4', 'kmriiwa_joint_5', 'kmriiwa_joint_6','kmriiwa_joint_7']


q_upper_limit = [
    robot_description.joint_map[i].limit.upper - 0.07 for i in joint_states_positions.name]
q_lower_limit = [
    robot_description.joint_map[i].limit.lower + 0.07 for i in joint_states_positions.name]

qdot_limit = [
    robot_description.joint_map[i].limit.velocity for i in joint_states_positions.name]

print('Robot joints angles are',q_upper_limit)
print('Robot joints angles lower are',q_lower_limit)

# PyKDL_Util here
# pykdl_util_kin = KDLKinematics(robot_description, "kmriiwa_base_footprint", "kmriiwa_link_ee")


# Differential jacobian here
# vel_ik_solver = PyKDL.ChainIkSolverVel_pinv(kdl_chain, 0.0001, 1000)



class kmr_iiwa_base_move():
    def __init__(self):

        ### Declare all variables here
        ## All joint states are declared here
        self.joint_states_positions = JointState()

        self.a0 = Float32()
        self.a1 = Float32()
        self.a2 = Float32()
        self.a3 = Float32()
        self.a4 = Float32()
        self.a5 = Float32()
        self.a6 = Float32()

        self.mutex1 = Lock()
        
        self.robot_joint_states = JointState()
        self.iiwa_jointstatemsg = JointState()
        
        ## I am creating my PyKDL FK and IK functionalities based on Pykdl here
        self.fk_kdl = PyKDL.ChainFkSolverPos_recursive(kdl_chain)
        self.ik_v_kdl = PyKDL.ChainIkSolverVel_pinv(kdl_chain)
        self.ik_p_kdl = PyKDL.ChainIkSolverPos_NR(kdl_chain, self.fk_kdl, self.ik_v_kdl)
        ## All arm parameters are declared here ######
        
        self.joint_states_positions.name =  ['kmriiwa_joint_1', 'kmriiwa_joint_2','kmriiwa_joint_3', 'kmriiwa_joint_4', 'kmriiwa_joint_5', 'kmriiwa_joint_6','kmriiwa_joint_7']
        
        
        
        self.robot_joint_states.position = [0, 0, 0, 0, 0, 0, 0]
        self.iiwa_jointstatemsg.position = [0, 0, 0, 0, 0, 0, 0]
        
        
        ## My cartesian frame is
        self.cartesian_frame = PyKDL.Frame()

        #self.twist_output = PyKDL.Twist()

        #self.test_output_twist = PyKDL.Twist()

        # Define joint output array using PyKDL
        self.q_out = PyKDL.JntArray(kdl_chain.getNrOfJoints())
        
        self.q_in = PyKDL.JntArray(kdl_chain.getNrOfJoints())
        
        # Current joint states in numpy
        # Faster iterations of joints in numpy
        self.q_current_numpy = zeros(7)
        
        ## Initialize KDL's IK Solver here
        ## Ensure chain is already built during the start
        # SVD damped
        # FK SOLVER
        # Get the end-effector position first
        self.fk_kdl.JntToCart(self.q_in,self.cartesian_frame,-1)
        
        # IK SOLVER - Positional IK 
        self.ik_p_kdl.CartToJnt(self.q_in,self.cartesian_frame,self.q_out)

        # Forward Kinematics solver to obtain the pose of the end-effector
        
        
        
        
        
        self.robot_joint_states = JointState()
        self.iiwa_jointstatemsg = JointState()
        # self.iiwa_cartesian_wrench_msg = WrenchStamped()

        self.robot_joint_states.position = [0, 0, 0, 0, 0, 0, 0]
        self.iiwa_jointstatemsg.position = [0, 0, 0, 0, 0, 0, 0]
        
        
        self.joint_states_arr = numpy.zeros(7)
        self.pick_place_task_success = 0
        # Get the trajectory response  here
        self.traj_response = String()
        
        # Aruco marker with respect to camera
        self.aruco_pos_wrt_camera = PoseStamped()
        self.aruco_pos_wrt_base = PoseStamped()
        
        
        self.robot_joint_positions_to_aruco_pose = JointState()
        self.robot_joint_positions_to_aruco_pose = [0,0,0,0,0,0,0]      
        
        self.q_upper_limit = [
            robot_description.joint_map[i].limit.upper - 0.07 for i in self.joint_states_positions.name]
        self.q_lower_limit = [
            robot_description.joint_map[i].limit.lower + 0.07 for i in self.joint_states_positions.name]

        self.qdot_limit = [
            robot_description.joint_map[i].limit.velocity for i in self.joint_states_positions.name]
        
        print('Robot joints angles are',self.q_upper_limit)
        print('Robot joints angles lower are',self.q_lower_limit)




        ## Move base client 
        self.client = actionlib.SimpleActionClient('/kmriiwa/move_base',MoveBaseAction)

        # Keep track of the joint states continously
        self.joint_state_subscriber = rospy.Subscriber("kmriiwa/arm/joint_states",JointState,self.joint_state_callback,queue_size=1)

        # Gripper close Publisher
        self.gripper_close_publisher = rospy.Publisher("/kmriiwa/base/command/gripperActionClose",String,queue_size=1)


        # Gripper open Publisher
        self.gripper_open_publisher = rospy.Publisher("/kmriiwa/base/command/gripperActionOpen",String,queue_size=1)


        self.response_trajectory = rospy.Subscriber("/kmriiwa/arm/state/JointPositionReached",String,self.trajectory_action_completed,queue_size=1)

        # Publish the desired trajectory here -> Make this action client later when you have the fucking time!!!
        self.traj_desired_publisher = rospy.Publisher('/kmriiwa/arm/command/JointPosition',JointPosition,queue_size=1)
        
        # Subscribe to Aruco marker here
        # Set up ArUco pose subscriber
        self.current_aruco_pose_wrt_camera = rospy.Subscriber("/aruco_single/pose", PoseStamped, self.aruco_pose_callback)
        

        self.current_aruco_pose_wrt_basefoot = rospy.Subscriber("/aruco_final_pose/pose",Pose,self.aruco_pose_baseframe_callback)
        
        self.traj_number = -10000

    def joint_state_callback(self,joint_states):
        self.joint_states_arr[0] = joint_states.position[0]
        self.joint_states_arr[1] = joint_states.position[1]
        self.joint_states_arr[2] = joint_states.position[2]
        self.joint_states_arr[3] = joint_states.position[3]
        self.joint_states_arr[4] = joint_states.position[4]
        self.joint_states_arr[5] = joint_states.position[5]
        self.joint_states_arr[6] = joint_states.position[6]
        
        
        self.q_in[0] = joint_states.position[0]
        self.q_in[1] = joint_states.position[1]
        self.q_in[2] = joint_states.position[2]
        self.q_in[3] = joint_states.position[3]
        self.q_in[4] = joint_states.position[4]
        self.q_in[5] = joint_states.position[5]
        self.q_in[6] = joint_states.position[6]
        
        
        print('self.joint_states_positions',self.joint_states_arr)


        #print('self.joint_states_positions',joint_states.position)
    def gripper_close_action(self):
        gripper_close_msg = String()
        gripper_close_msg.data=''

        self.gripper_close_publisher.publish(gripper_close_msg)
        # Sleep for few seconds
        rospy.sleep(1.5)
        gripper_close_resp = True
        
        return gripper_close_resp
    
    def gripper_open_action(self):
        gripper_open_msg = String()
        gripper_open_msg.data=''

        self.gripper_open_publisher.publish(gripper_open_msg)
        # Sleep for few seconds
        rospy.sleep(1.5)
        gripper_open_resp = True
        print('Traj number',self.traj_number)
        return gripper_open_resp

    def aruco_pose_callback(self,aruco_pose_wrt_camera):
        
        
        self.aruco_pos_wrt_camera = aruco_pose_wrt_camera
        print('This is my aruco pose',self.aruco_pos_wrt_camera)
    
    def aruco_pose_baseframe_callback(self,aruco_pose_wrt_baseframe):
        
        
        self.aruco_pos_wrt_base = aruco_pose_wrt_baseframe
        print('This is my aruco pose',self.aruco_pos_wrt_base)
        
        

    
    
    def pick_action(self,start_points,pick_points): ## TODO Worst implementation make gripper open close as service !!!!!

        resp = self.trajectory_action(start_points)

        print('resp of pick is',resp)
        resp_pick = False
        if resp == True:
            resp1 = self.gripper_open_action()
            if resp1 == True:
                resp2 = self.trajectory_action(pick_points)
                if resp2 == True:
                    resp3 = self.gripper_close_action()
                    if resp3 == True:
                        resp4 = self.trajectory_action(start_points)
                        if resp4 == True:
                            print('Pick action successful')
                            resp_pick = True
                        
        return resp_pick

    def place_action(self,start_points,place_points): ## TODO Worst implementation make gripper open close as service !!!!! and Trajectory as Actionclient

        resp = self.trajectory_action(start_points)
        resp_place = False
        
        if resp == True:
            resp2 = self.trajectory_action(place_points)
            if resp2 == True:
                resp3 = self.gripper_open_action()
                if resp3 == True:
                    resp4 = self.trajectory_action(start_points)

                    if resp4 == True:
                        print('Place action successful')
                        resp_place = True
                    else:
                        resp_places = False
        return resp_place

    def trajectory_action_completed(self,resp_traj):
        self.traj_response.data = resp_traj.data
        print('trajectory response',self.traj_response)
        if self.traj_response.data == "done":
            print('i am winning')
        #     self.traj_response.data = ''                
        # if self.traj_response.data == '':
        #     print('i am sleeping')

    def compute_pick_pose_using_IK(self,move_to_aruco_pose):
        

        self 
        
        
    #     self.pick_pose_wrt_baselink = 
    
    def trajectory_action(self,joint_position_desired):
        self.mutex1.acquire()
        
        #joint_position_radians = Float32MultiArray()
        #joint_position_radians.layout = 
        #for i in range(len(joint_position_desired)):
        self.a0.data = deg2rad(joint_position_desired[0])
        self.a1.data = deg2rad(joint_position_desired[1])
        self.a2.data = deg2rad(joint_position_desired[2])
        self.a3.data = deg2rad(joint_position_desired[3])
        self.a4.data = deg2rad(joint_position_desired[4])
        self.a5.data = deg2rad(joint_position_desired[5])
        self.a6.data = deg2rad(joint_position_desired[6])

        
        joint_position_msg = JointPosition()
        joint_position_msg.a1 = self.a0.data
        joint_position_msg.a2 = self.a1.data
        joint_position_msg.a3 = self.a2.data
        joint_position_msg.a4 = self.a3.data
        joint_position_msg.a5 = self.a4.data
        joint_position_msg.a6 = self.a5.data
        joint_position_msg.a7 = self.a6.data
        

        self.traj_desired_publisher.publish(joint_position_msg)
        self.mutex1.release()
        print('I am executing this trajectory',self.traj_number)
        rospy.sleep(10)
        if self.traj_response.data == "done":
            # Do this to get ready for next trajectory point sent
            self.traj_response.data=''
            resp = True
            
        else:
            resp = False
        
        return resp        
    def move_to_aruco_offset_pose(self,aruco_pose_cartesian):
        print('I am moving to aruco')
        ## Check and do IK and send pos
        ## Assumption that aruco_pose is transformed in cartesian frame
        offset_pose = PyKDL.Frame(aruco_pose_cartesian.Rot, aruco_pose_cartesian.p)
        
        
        ## IK function such that self.q_out has all the joints necessary for reaching aruco
        self.ik_p_kdl(self.q_in,self.aruco_pos_wrt_base,self.q_out)
            
        
    def start_pick_and_place(self):
        
        ### I dont want to use the old robot start pick and place points here #######
        
        #### I am commenting below ##############################################
        '''
        start_robot_points = numpy.array([[87.65,-38.02,0.0,92.27,0,-46.71,58.47],
                                    [87.65,-38.02,0.0,92.27,0,-46.71,58.47],
                                    [87.81,-43.29,0,88.10,0,-45.65,58.70],
                                    [88.10,-51.47,0,71.35,0,-58.03,59.16]])


        robot_points = numpy.array([[87.65,-46.92,0.0,95.66,0.0,-37.42,58.47],
                                    [87.65,-46.92,0.0,95.66,0.0,-37.42,58.47],
                                        [87.81,-50.32,0,88.22,0,-38.47,58.70],
                                        [88.10,-57.92,0,71.54,0,-51.39,59.22]])



        start_table_points = numpy.array([[160.72,-44.68,0,77.01,0,-58.30,131.53],
                                        [160.72,-44.68,0,77.01,0,-58.30,131.53],
                                        [156.18,-48.17,0,72.80,0,-59.04,126.99],
                                        [151.83,-50.24,0,66.31,0,-63.47,122.64]])



        table_points = numpy.array([[160.72,-50.99,0,78.35,0,-50.65,131.53],
                                    [160.72,-50.57,0,78.28,0,-51.06,131.53],
                                        [156.18,-52.85,0,73.62,0,-53.95,126.99],
                                        [151.83,-55.83,0,67.59,0,-56.98,122.64]])
        
        
        
        

        ## Table place points -- This is temporary Do IK here and reorient the base points 
        
        ## I am doing aruco marker detection here 
        
        

        
        for ijk in range(0,numpy.shape(start_robot_points)[0]):
            print('I am inside for-loop',ijk)
            self.traj_number = ijk
            print('start_robot_points',start_robot_points[ijk])
            print('robot_points',robot_points[ijk])
            resp_pick_action = self.pick_action(start_robot_points[ijk],robot_points[ijk])

            print('Pick response',resp_pick_action)

            if resp_pick_action == True:
                resp_place_action = self.place_action(start_table_points[ijk], table_points[ijk])

                if resp_place_action == True:
                    self.pick_place_task_success += 1
                    print('Pick and place action Successful')

                else:
                    print('Error somewhere')

        print('self.traj_number-1',self.traj_number)
        print('self.pick_place_task_success',self.pick_place_task_success)

        if (self.traj_number) == self.pick_place_task_success:
            self.traj_number = 0
            print('I am starting to pick from the table dont move')
            for ijk in range(1,numpy.shape(start_robot_points)[0]):
                print('I am inside for-loop',ijk)
                self.traj_number = ijk
                print('start_robot_points',start_robot_points[ijk])
                print('robot_points',robot_points[ijk])
                
                difference_array = numpy.array([0,0.4200,0,-0.07,0,-0.41,0])
                resp_pick_action = self.pick_action(start_table_points[ijk],table_points[ijk])

                print('Pick response',resp_pick_action)

                if resp_pick_action == True:
                    resp_place_action = self.place_action(start_robot_points[ijk], numpy.ravel(robot_points[ijk]) - numpy.ravel(difference_array))

                    if resp_place_action == True:
                        print('Pick and place action Successful')

                    else:
                        print('Error somewhere')

        else:
            print('Cant do pick and place from table to robot !!!')
        '''
        
    def movebase_client(self,x):
        self.client.wait_for_server()
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()
        goal.target_pose.pose.position.x = float(x[0]) #(0,0 Infront of Keerthi cell -> Map = bay3_v02 )
        goal.target_pose.pose.position.y = float(x[1])
        goal.target_pose.pose.orientation.x = float(x[2])
        goal.target_pose.pose.orientation.y = float(x[3])
        goal.target_pose.pose.orientation.z = float(x[4])
        goal.target_pose.pose.orientation.w = float(x[5])

        self.client.send_goal(goal)
        wait = self.client.wait_for_result()
        if not wait:
            rospy.logerr("Action server not available!")
            rospy.signal_shutdown("Action server not available!")
        else:
            return self.client.get_result() 


if __name__ == '__main__':
    
    position_lists = []





    try:
        rospy.init_node('movebase_client_py')
        
        ## This is the base class function all - Sub functions are defined here -> Both arm and also mobile base
        ### I am initiating my base class here
        ## I have created an instance of my move action
        ## Commented below
        kmr_iiwa_move = kmr_iiwa_base_move()
        
        
        
        ### I am doing pick and place here ######
        ## Here I am instantiating all the necessesites for pick and place action
        ## Commented below
        #kmr_iiwa_move.start_pick_and_place()
        rospy.spin()

        # while not rospy.is_shutdown():
        #     print('')
        
        # position_lists.append([-4.75, 1.35,0,0,0,1]) # Aswin cell
        # position_lists.append([0,1.35,0,0,0,1]) # PENN Cell
        # position_lists.append([0,0,0,0,0,1]) # Keerthi Cell
        # Program the cube pick and place


        ### make all ARM commands above here
        # position_lists.append([0,0,0,0,0.9999997,0.0007963]) # Arm and base reorient
        # position_lists.append([-4.75,0.5,0,0,1,0.0]) # Aayush cell
        # position_lists.append([-8.75,0.5,0,0,1,0.00])  # Near Bay 3- blue lines
        # position_lists.append([-4.75, 1.35,0,0,0,1]) # Aswin Cell
        # print(position_lists)
        
        # for number_of_positions in range(0,len(position_lists)):
        #     positions = (position_lists[number_of_positions])
        #     results = kmr_iiwa_move.movebase_client(positions)
        #     if results:
        #         rospy.loginfo("Goal execution done!")


    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation test finished.")

        # /kmriiwa/base/state/RobotStatus