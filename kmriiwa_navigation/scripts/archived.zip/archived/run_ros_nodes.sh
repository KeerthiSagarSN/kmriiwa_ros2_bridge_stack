#!/bin/bash

echo "Running 3D Printing Cell"
rosrun kmriiwa_navigation move_base_coresense.py

sleep 1

#echo "Running Arm Motion"
#roslaunch kmriiwa_moveit arm.launch
#sleep 1

echo "Running Inspection cell"
rosrun kmriiwa_navigation move_base_coresense_2.py
sleep 1

echo "Running Inspection Arm Motion"
roslaunch kmriiwa_moveit arm_2.launch
sleep 1

echo "Running Assembly cell"
rosrun kmriiwa_navigation move_base_coresense_3.py
sleep 1

echo "Running Back to initial point"

rosrun kmriiwa_navigation move_base_coresense_4.py
